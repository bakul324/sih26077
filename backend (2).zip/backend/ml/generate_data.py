import numpy as np
import pandas as pd
from pathlib import Path

np.random.seed(42)

N = 10000

latitude = np.random.uniform(20.0, 24.5, N)
longitude = np.random.uniform(85.0, 89.0, N)

temperature = np.random.normal(29, 4, N)
humidity = np.random.uniform(45, 98, N)
pressure = np.random.normal(1005, 8, N)

wind_u = np.random.normal(0, 8, N)
wind_v = np.random.normal(0, 8, N)

rainfall = np.random.exponential(5, N)

iwv = (
    humidity * 0.35
    + temperature * 0.20
    + np.random.normal(0, 2, N)
)

cape = (
    temperature * 25
    + humidity * 12
    + np.random.normal(0, 100, N)
)

cin = (
    150
    - humidity * 1.2
    + np.random.normal(0, 15, N)
)

ctt = (
    240
    - humidity * 0.15
    + np.random.normal(0, 4, N)
)

ctt_drop_rate = np.random.uniform(0, 8, N)

wind_convergence = np.random.uniform(-10, 10, N)

wind_shear = np.random.uniform(0, 30, N)

elevation = np.random.uniform(5, 800, N)

slope = np.random.uniform(0, 40, N)

severity = (
    cape * 0.002
    + humidity * 0.03
    + rainfall * 0.04
    + iwv * 0.02
    + ctt_drop_rate * 0.10
    + wind_convergence * 0.04
    + wind_shear * 0.01
)

severity += np.random.normal(0, 0.5, N)

thunderstorm = (
    severity > 3.8
).astype(int)

cloudburst = (
    (rainfall > 12)
    & (humidity > 75)
    & (severity > 4.0)
).astype(int)

flash_flood = (
    (rainfall > 15)
    & (elevation < 300)
    & (slope > 5)
    & (severity > 4.2)
).astype(int)

data = pd.DataFrame({
    "latitude": latitude,
    "longitude": longitude,
    "temperature": temperature,
    "humidity": humidity,
    "pressure": pressure,
    "wind_u": wind_u,
    "wind_v": wind_v,
    "rainfall": rainfall,
    "iwv": iwv,
    "cape": cape,
    "cin": cin,
    "ctt": ctt,
    "ctt_drop_rate": ctt_drop_rate,
    "wind_convergence": wind_convergence,
    "wind_shear": wind_shear,
    "elevation": elevation,
    "slope": slope,
    "thunderstorm": thunderstorm,
    "cloudburst": cloudburst,
    "flash_flood": flash_flood
})

output = Path("data/sample/weather_dataset.csv")

output.parent.mkdir(
    parents=True,
    exist_ok=True
)

data.to_csv(output, index=False)

print("=" * 60)
print("SIH26077 SAMPLE DATASET")
print("=" * 60)

print("Records:", len(data))
print("Columns:", len(data.columns))

print("\nHazard labels:")
print("Thunderstorm:", int(data["thunderstorm"].sum()))
print("Cloudburst:", int(data["cloudburst"].sum()))
print("Flash flood:", int(data["flash_flood"].sum()))

print("\nSaved:")
print(output.resolve())