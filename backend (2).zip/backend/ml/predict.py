import pandas as pd
import joblib
from pathlib import Path


# ============================================================
# SIH26077 PREDICTION ENGINE
# ============================================================

MODEL_DIR = Path("data/models")


# ============================================================
# LOAD MODELS
# ============================================================

thunderstorm_model = joblib.load(
    MODEL_DIR / "thunderstorm_model.pkl"
)

cloudburst_model = joblib.load(
    MODEL_DIR / "cloudburst_model.pkl"
)

flash_flood_model = joblib.load(
    MODEL_DIR / "flash_flood_model.pkl"
)


# ============================================================
# FEATURES
# ============================================================

FEATURES = [
    "temperature",
    "humidity",
    "pressure",
    "wind_u",
    "wind_v",
    "rainfall",
    "iwv",
    "cape",
    "cin",
    "ctt",
    "ctt_drop_rate",
    "wind_convergence",
    "wind_shear",
    "elevation",
    "slope"
]


# ============================================================
# RISK CLASSIFICATION
# ============================================================

def risk_level(probability):

    if probability >= 80:
        return "EXTREME"

    elif probability >= 60:
        return "HIGH"

    elif probability >= 40:
        return "MODERATE"

    elif probability >= 20:
        return "LOW"

    else:
        return "VERY LOW"


# ============================================================
# PREDICTION FUNCTION
# ============================================================

def predict_weather(weather_data):

    # Convert dictionary to dataframe
    input_data = pd.DataFrame(
        [weather_data]
    )

    # Make sure feature order is correct
    input_data = input_data[FEATURES]

    # -----------------------------------------
    # Thunderstorm probability
    # -----------------------------------------

    thunderstorm_probability = (
        thunderstorm_model.predict_proba(
            input_data
        )[0][1] * 100
    )

    # -----------------------------------------
    # Cloudburst probability
    # -----------------------------------------

    cloudburst_probability = (
        cloudburst_model.predict_proba(
            input_data
        )[0][1] * 100
    )

    # -----------------------------------------
    # Flash flood probability
    # -----------------------------------------

    flash_flood_probability = (
        flash_flood_model.predict_proba(
            input_data
        )[0][1] * 100
    )

    # -----------------------------------------
    # Overall risk
    # -----------------------------------------

    overall_probability = max(
        thunderstorm_probability,
        cloudburst_probability,
        flash_flood_probability
    )

    return {
        "thunderstorm_probability":
            round(thunderstorm_probability, 2),

        "cloudburst_probability":
            round(cloudburst_probability, 2),

        "flash_flood_probability":
            round(flash_flood_probability, 2),

        "overall_probability":
            round(overall_probability, 2),

        "risk_level":
            risk_level(overall_probability)
    }


# ============================================================
# TEST PREDICTION
# ============================================================

if __name__ == "__main__":

    sample_weather = {

        "temperature": 32.0,

        "humidity": 88.0,

        "pressure": 998.0,

        "wind_u": 5.0,

        "wind_v": -3.0,

        "rainfall": 18.0,

        "iwv": 38.0,

        "cape": 1800.0,

        "cin": 30.0,

        "ctt": 225.0,

        "ctt_drop_rate": 6.0,

        "wind_convergence": 7.0,

        "wind_shear": 20.0,

        "elevation": 120.0,

        "slope": 15.0
    }

    result = predict_weather(
        sample_weather
    )

    print()
    print("=" * 60)
    print("SIH26077 WEATHER PREDICTION")
    print("=" * 60)

    print(
        "Thunderstorm:",
        result["thunderstorm_probability"],
        "%"
    )

    print(
        "Cloudburst:",
        result["cloudburst_probability"],
        "%"
    )

    print(
        "Flash Flood:",
        result["flash_flood_probability"],
        "%"
    )

    print(
        "Overall:",
        result["overall_probability"],
        "%"
    )

    print(
        "Risk:",
        result["risk_level"]
    )

    print("=" * 60)