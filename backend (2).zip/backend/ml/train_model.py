import pandas as pd
import joblib

from pathlib import Path

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report


# ==========================================
# 1. LOAD DATASET
# ==========================================

DATA_FILE = "data/sample/weather_dataset.csv"

data = pd.read_csv(DATA_FILE)

print("=" * 60)
print("SIH26077 AI MODEL TRAINING")
print("=" * 60)

print("Dataset loaded successfully")
print("Records:", len(data))
print("Features:", len(data.columns))


# ==========================================
# 2. INPUT FEATURES
# ==========================================

features = [
    "temperature",
    "humidity",
    "pressure",
    "wind_u",
    "wind_v",
    "rainfall",
    "iwv",
    "cape",
    "cin",
    "ctt",
    "ctt_drop_rate",
    "wind_convergence",
    "wind_shear",
    "elevation",
    "slope"
]

X = data[features]


# ==========================================
# 3. CREATE MODEL DIRECTORY
# ==========================================

model_directory = Path("data/models")

model_directory.mkdir(
    parents=True,
    exist_ok=True
)


# ==========================================
# 4. HAZARD MODELS
# ==========================================

targets = {
    "thunderstorm": "thunderstorm_model.pkl",
    "cloudburst": "cloudburst_model.pkl",
    "flash_flood": "flash_flood_model.pkl"
}


# ==========================================
# 5. TRAIN EACH MODEL
# ==========================================

for target, filename in targets.items():

    print("\n")
    print("=" * 60)
    print("TRAINING:", target.upper())
    print("=" * 60)

    y = data[target]

    print("Positive events:", int(y.sum()))
    print("Negative events:", int((y == 0).sum()))

    # ------------------------------
    # Train/Test split
    # ------------------------------

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.20,
        random_state=42,
        stratify=y
    )

    # ------------------------------
    # Random Forest
    # ------------------------------

    model = RandomForestClassifier(
        n_estimators=200,
        max_depth=15,
        min_samples_split=5,
        random_state=42,
        class_weight="balanced",
        n_jobs=-1
    )

    # ------------------------------
    # Train
    # ------------------------------

    print("Training model...")

    model.fit(
        X_train,
        y_train
    )

    # ------------------------------
    # Prediction
    # ------------------------------

    predictions = model.predict(X_test)

    # ------------------------------
    # Accuracy
    # ------------------------------

    accuracy = accuracy_score(
        y_test,
        predictions
    )

    print(
        "Accuracy:",
        round(accuracy, 4)
    )

    # ------------------------------
    # Report
    # ------------------------------

    print("\nClassification Report:")

    print(
        classification_report(
            y_test,
            predictions,
            zero_division=0
        )
    )

    # ------------------------------
    # Save model
    # ------------------------------

    model_path = model_directory / filename

    joblib.dump(
        model,
        model_path
    )

    print(
        "Model saved:",
        model_path
    )


# ==========================================
# COMPLETE
# ==========================================

print("\n")
print("=" * 60)
print("ALL SIH26077 MODELS TRAINED SUCCESSFULLY")
print("=" * 60)

print("\nModels:")
print("1. thunderstorm_model.pkl")
print("2. cloudburst_model.pkl")
print("3. flash_flood_model.pkl")

print("\nLocation:")
print("D:\\SIH26077\\data\\models")