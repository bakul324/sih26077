import numpy as np
import pandas as pd
import joblib

from pathlib import Path


# ============================================================
# SIH26077 RISK GRID ENGINE
# ============================================================

MODEL_DIR = Path("data/models")


# ============================================================
# LOAD MODELS
# ============================================================

thunderstorm_model = joblib.load(
    MODEL_DIR / "thunderstorm_model.pkl"
)

cloudburst_model = joblib.load(
    MODEL_DIR / "cloudburst_model.pkl"
)

flash_flood_model = joblib.load(
    MODEL_DIR / "flash_flood_model.pkl"
)


FEATURES = [
    "temperature",
    "humidity",
    "pressure",
    "wind_u",
    "wind_v",
    "rainfall",
    "iwv",
    "cape",
    "cin",
    "ctt",
    "ctt_drop_rate",
    "wind_convergence",
    "wind_shear",
    "elevation",
    "slope"
]


# ============================================================
# CREATE GRID
# ============================================================

def create_grid(
    min_lat=20.0,
    max_lat=24.5,
    min_lon=85.0,
    max_lon=89.0,
    resolution=0.1
):

    latitudes = np.arange(
        min_lat,
        max_lat + resolution,
        resolution
    )

    longitudes = np.arange(
        min_lon,
        max_lon + resolution,
        resolution
    )

    grid = []

    for lat in latitudes:

        for lon in longitudes:

            grid.append({
                "latitude": round(float(lat), 4),
                "longitude": round(float(lon), 4)
            })

    return pd.DataFrame(grid)


# ============================================================
# GENERATE DEVELOPMENT WEATHER CONDITIONS
# ============================================================

def add_weather_features(grid):

    np.random.seed(42)

    n = len(grid)

    grid["temperature"] = np.random.normal(
        29,
        4,
        n
    )

    grid["humidity"] = np.random.uniform(
        45,
        98,
        n
    )

    grid["pressure"] = np.random.normal(
        1005,
        8,
        n
    )

    grid["wind_u"] = np.random.normal(
        0,
        8,
        n
    )

    grid["wind_v"] = np.random.normal(
        0,
        8,
        n
    )

    grid["rainfall"] = np.random.exponential(
        5,
        n
    )

    grid["iwv"] = (
        grid["humidity"] * 0.35
        + grid["temperature"] * 0.20
    )

    grid["cape"] = (
        grid["temperature"] * 25
        + grid["humidity"] * 12
    )

    grid["cin"] = (
        150
        - grid["humidity"] * 1.2
    )

    grid["ctt"] = (
        240
        - grid["humidity"] * 0.15
    )

    grid["ctt_drop_rate"] = np.random.uniform(
        0,
        8,
        n
    )

    grid["wind_convergence"] = np.random.uniform(
        -10,
        10,
        n
    )

    grid["wind_shear"] = np.random.uniform(
        0,
        30,
        n
    )

    grid["elevation"] = np.random.uniform(
        5,
        800,
        n
    )

    grid["slope"] = np.random.uniform(
        0,
        40,
        n
    )

    return grid


# ============================================================
# GENERATE RISK
# ============================================================

def generate_risk_grid():

    grid = create_grid()

    grid = add_weather_features(
        grid
    )

    X = grid[FEATURES]

    # ----------------------------------------
    # Predictions
    # ----------------------------------------

    grid["thunderstorm_probability"] = (
        thunderstorm_model
        .predict_proba(X)[:, 1]
        * 100
    )

    grid["cloudburst_probability"] = (
        cloudburst_model
        .predict_proba(X)[:, 1]
        * 100
    )

    grid["flash_flood_probability"] = (
        flash_flood_model
        .predict_proba(X)[:, 1]
        * 100
    )

    # ----------------------------------------
    # Overall probability
    # ----------------------------------------

    grid["overall_probability"] = grid[
        [
            "thunderstorm_probability",
            "cloudburst_probability",
            "flash_flood_probability"
        ]
    ].max(axis=1)

    # ----------------------------------------
    # Risk category
    # ----------------------------------------

    grid["risk_level"] = pd.cut(
        grid["overall_probability"],
        bins=[
            -1,
            20,
            40,
            60,
            80,
            101
        ],
        labels=[
            "VERY LOW",
            "LOW",
            "MODERATE",
            "HIGH",
            "EXTREME"
        ]
    )

    return grid


# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":

    print("=" * 60)
    print("SIH26077 RISK GRID")
    print("=" * 60)

    grid = generate_risk_grid()

    output = Path(
        "data/processed/risk_grid.csv"
    )

    output.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    grid.to_csv(
        output,
        index=False
    )

    print("Grid cells:", len(grid))

    print("\nRisk distribution:")

    print(
        grid["risk_level"]
        .value_counts()
    )

    print("\nSaved:")
    print(output.resolve())