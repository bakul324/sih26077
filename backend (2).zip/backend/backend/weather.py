import requests


# ==============================
# CURRENT WEATHER
# ==============================

def get_weather(latitude, longitude):

    url = "https://api.open-meteo.com/v1/forecast"

    params = {
        "latitude": latitude,
        "longitude": longitude,
        "current": (
            "temperature_2m,"
            "relative_humidity_2m,"
            "surface_pressure,"
            "wind_speed_10m,"
            "precipitation"
        ),
        "timezone": "auto"
    }

    response = requests.get(
        url,
        params=params,
        timeout=10
    )

    response.raise_for_status()

    data = response.json()

    current = data.get("current", {})

    return {
        "temperature": current.get("temperature_2m", 0),
        "humidity": current.get("relative_humidity_2m", 0),
        "pressure": current.get("surface_pressure", 0),
        "wind_speed": current.get("wind_speed_10m", 0),
        "rainfall": current.get("precipitation", 0),

        # Future ML / atmospheric parameters
        "wind_u": 0,
        "wind_v": 0,
        "iwv": 0,
        "cape": 0,
        "cin": 0,
        "ctt": 0,
        "ctt_drop_rate": 0,
        "wind_convergence": 0,
        "wind_shear": 0,
        "elevation": 0,
        "slope": 0
    }


# ==============================
# 24-HOUR FORECAST
# ==============================

def get_forecast(latitude, longitude):

    url = "https://api.open-meteo.com/v1/forecast"

    params = {
        "latitude": latitude,
        "longitude": longitude,

        "hourly": (
            "temperature_2m,"
            "relative_humidity_2m,"
            "surface_pressure,"
            "wind_speed_10m,"
            "precipitation"
        ),

        "forecast_days": 1,

        "timezone": "auto"
    }

    response = requests.get(
        url,
        params=params,
        timeout=10
    )

    response.raise_for_status()

    data = response.json()

    hourly = data.get("hourly", {})

    times = hourly.get("time", [])

    result = []

    for i, time in enumerate(times):

        result.append({

            "time": time,

            "temperature":
                hourly.get(
                    "temperature_2m",
                    [0] * len(times)
                )[i],

            "humidity":
                hourly.get(
                    "relative_humidity_2m",
                    [0] * len(times)
                )[i],

            "pressure":
                hourly.get(
                    "surface_pressure",
                    [0] * len(times)
                )[i],

            "wind_speed":
                hourly.get(
                    "wind_speed_10m",
                    [0] * len(times)
                )[i],

            "rainfall":
                hourly.get(
                    "precipitation",
                    [0] * len(times)
                )[i],

            "wind_u": 0,
            "wind_v": 0,
            "iwv": 0,
            "cape": 0,
            "cin": 0,
            "ctt": 0,
            "ctt_drop_rate": 0,
            "wind_convergence": 0,
            "wind_shear": 0,
            "elevation": 0,
            "slope": 0
        })

    return result