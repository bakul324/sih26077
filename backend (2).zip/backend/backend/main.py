
# ============================================================
# SIH26077
# AI DRIVEN HYPER-LOCAL EARLY WARNING SYSTEM
# ============================================================
#
# Advanced FastAPI Backend
#
# Main capabilities:
# 1. Health monitoring
# 2. Backend status
# 3. Location validation
# 4. Real-time weather
# 5. 24-hour forecast
# 6. Thunderstorm risk
# 7. Cloudburst risk
# 8. Flash-flood risk
# 9. Heavy-rain risk
# 10. Heat risk
# 11. Wind risk
# 12. Humidity risk
# 13. Overall risk engine
# 14. Risk level classification
# 15. Hazard summary
# 16. Regional risk grid
# 17. Dashboard summary
# 18. Manual prediction
# 19. Location prediction
# 20. Forecast prediction
# 21. Alert generation
# 22. Early-warning messages
# 23. Risk explanation
# 24. Safety recommendations
# 25. Atmospheric indicator support
# 26. CAPE support
# 27. CIN support
# 28. IWV support
# 29. CTT support
# 30. CTT drop-rate support
# 31. Wind convergence support
# 32. Wind shear support
# 33. Elevation support
# 34. Slope support
# 35. API test endpoint
# 36. CORS
# 37. Exception handling
# 38. Timestamping
# 39. Coordinate metadata
# 40. Forecast statistics
# 41. Maximum-risk detection
# 42. Alert severity
# 43. Risk confidence
# 44. Monitoring status
# 45. System metadata
# 46. API documentation
# 47. Modular risk engine
# 48. Dashboard-ready JSON
# 49. Regional monitoring
# 50. Future ML integration ready
#
# ============================================================

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from pydantic import BaseModel, Field

from datetime import datetime
from typing import Optional, List, Dict, Any

import math
import traceback


# ============================================================
# WEATHER MODULE
# ============================================================

try:
    from backend.weather import get_weather, get_forecast
except Exception as import_error:

    get_weather = None
    get_forecast = None

    print("WARNING: backend.weather could not be imported.")
    print(import_error)


# ============================================================
# APPLICATION
# ============================================================

app = FastAPI(

    title="SIH26077",

    description=(
        "AI Driven Hyper-Local Early Warning System "
        "for multi-hazard disaster risk monitoring."
    ),

    version="3.0.0",

    docs_url="/docs",

    redoc_url="/redoc"
)


# ============================================================
# CORS
# ============================================================

app.add_middleware(

    CORSMiddleware,

    allow_origins=["*"],

    allow_credentials=True,

    allow_methods=["*"],

    allow_headers=["*"]
)


# ============================================================
# SYSTEM INFORMATION
# ============================================================

PROJECT_NAME = "SIH26077"

PROJECT_TITLE = (
    "AI Driven Hyper-Local Early Warning System"
)

VERSION = "3.0.0"

STARTED_AT = datetime.now().isoformat()


# ============================================================
# MODELS
# ============================================================


class LocationInput(BaseModel):

    latitude: float = Field(
        ...,
        ge=-90,
        le=90
    )

    longitude: float = Field(
        ...,
        ge=-180,
        le=180
    )


class WeatherInput(BaseModel):

    temperature: float = 0

    humidity: float = Field(
        0,
        ge=0,
        le=100
    )

    pressure: float = 0

    wind_u: float = 0

    wind_v: float = 0

    wind_speed: float = 0

    rainfall: float = Field(
        0,
        ge=0
    )

    iwv: float = 0

    cape: float = 0

    cin: float = 0

    ctt: float = 0

    ctt_drop_rate: float = 0

    wind_convergence: float = 0

    wind_shear: float = 0

    elevation: float = 0

    slope: float = 0


class PredictionResponse(BaseModel):

    project: str

    weather: Dict[str, Any]

    prediction: Dict[str, Any]

    timestamp: str


# ============================================================
# HELPER FUNCTIONS
# ============================================================


def safe_float(
    value,
    default=0.0
):

    try:

        number = float(value)

        if math.isnan(number):
            return default

        if math.isinf(number):
            return default

        return number

    except Exception:

        return default


# ------------------------------------------------------------


def clamp(
    value,
    minimum=0,
    maximum=100
):

    value = safe_float(value)

    return max(
        minimum,
        min(
            maximum,
            value
        )
    )


# ------------------------------------------------------------


def risk_level(score):

    score = clamp(score)

    if score >= 85:

        return "EXTREME"

    if score >= 70:

        return "VERY HIGH"

    if score >= 50:

        return "HIGH"

    if score >= 30:

        return "MODERATE"

    if score >= 15:

        return "LOW"

    return "VERY LOW"


# ------------------------------------------------------------


def risk_class(score):

    level = risk_level(score)

    return level.lower().replace(
        " ",
        "-"
    )


# ============================================================
# INDIVIDUAL RISK ENGINES
# ============================================================


def calculate_thunderstorm_risk(weather):

    humidity = safe_float(
        weather.get("humidity")
    )

    temperature = safe_float(
        weather.get("temperature")
    )

    rainfall = safe_float(
        weather.get("rainfall")
    )

    wind = safe_float(
        weather.get("wind_speed")
    )

    cape = safe_float(
        weather.get("cape")
    )

    cin = safe_float(
        weather.get("cin")
    )

    shear = safe_float(
        weather.get("wind_shear")
    )

    ctt_drop = safe_float(
        weather.get("ctt_drop_rate")
    )

    score = 0

    # Humidity

    if humidity >= 95:
        score += 25

    elif humidity >= 85:
        score += 20

    elif humidity >= 75:
        score += 12

    elif humidity >= 65:
        score += 5

    # Temperature

    if temperature >= 32:
        score += 15

    elif temperature >= 28:
        score += 10

    elif temperature >= 25:
        score += 5

    # Rainfall

    if rainfall >= 20:
        score += 15

    elif rainfall >= 10:
        score += 10

    elif rainfall >= 5:
        score += 5

    # Wind

    if wind >= 30:
        score += 15

    elif wind >= 20:
        score += 10

    elif wind >= 10:
        score += 5

    # CAPE

    if cape >= 2500:
        score += 20

    elif cape >= 1500:
        score += 15

    elif cape >= 800:
        score += 8

    # CIN

    if cin <= -150:
        score += 5

    # Wind shear

    if shear >= 20:
        score += 10

    elif shear >= 10:
        score += 5

    # CTT drop

    if ctt_drop >= 5:
        score += 10

    elif ctt_drop >= 2:
        score += 5

    return clamp(score)


# ============================================================


def calculate_cloudburst_risk(weather):

    rainfall = safe_float(
        weather.get("rainfall")
    )

    humidity = safe_float(
        weather.get("humidity")
    )

    iwv = safe_float(
        weather.get("iwv")
    )

    ctt_drop = safe_float(
        weather.get("ctt_drop_rate")
    )

    convergence = safe_float(
        weather.get("wind_convergence")
    )

    score = 0

    if rainfall >= 40:
        score += 55

    elif rainfall >= 30:
        score += 45

    elif rainfall >= 20:
        score += 35

    elif rainfall >= 10:
        score += 25

    elif rainfall >= 5:
        score += 15

    elif rainfall >= 1:
        score += 5

    if humidity >= 95:
        score += 20

    elif humidity >= 90:
        score += 15

    elif humidity >= 80:
        score += 10

    if iwv >= 60:
        score += 15

    elif iwv >= 50:
        score += 10

    if convergence >= 10:
        score += 10

    elif convergence >= 5:
        score += 5

    if ctt_drop >= 5:
        score += 10

    elif ctt_drop >= 2:
        score += 5

    return clamp(score)


# ============================================================


def calculate_flash_flood_risk(weather):

    rainfall = safe_float(
        weather.get("rainfall")
    )

    humidity = safe_float(
        weather.get("humidity")
    )

    elevation = safe_float(
        weather.get("elevation")
    )

    slope = safe_float(
        weather.get("slope")
    )

    score = 0

    if rainfall >= 50:
        score += 60

    elif rainfall >= 30:
        score += 50

    elif rainfall >= 20:
        score += 40

    elif rainfall >= 10:
        score += 25

    elif rainfall >= 5:
        score += 15

    if humidity >= 90:
        score += 15

    elif humidity >= 80:
        score += 8

    # Lower elevation can increase flood exposure

    if elevation <= 20:
        score += 10

    elif elevation <= 50:
        score += 7

    elif elevation <= 100:
        score += 4

    # Slope

    if slope >= 15:
        score += 10

    elif slope >= 8:
        score += 6

    return clamp(score)


# ============================================================


def calculate_heavy_rain_risk(weather):

    rainfall = safe_float(
        weather.get("rainfall")
    )

    humidity = safe_float(
        weather.get("humidity")
    )

    iwv = safe_float(
        weather.get("iwv")
    )

    score = 0

    if rainfall >= 50:
        score += 70

    elif rainfall >= 30:
        score += 55

    elif rainfall >= 20:
        score += 40

    elif rainfall >= 10:
        score += 25

    elif rainfall >= 5:
        score += 15

    if humidity >= 90:
        score += 15

    elif humidity >= 80:
        score += 8

    if iwv >= 60:
        score += 15

    elif iwv >= 50:
        score += 8

    return clamp(score)


# ============================================================


def calculate_heat_risk(weather):

    temperature = safe_float(
        weather.get("temperature")
    )

    humidity = safe_float(
        weather.get("humidity")
    )

    score = 0

    if temperature >= 45:
        score += 80

    elif temperature >= 40:
        score += 65

    elif temperature >= 37:
        score += 50

    elif temperature >= 35:
        score += 35

    elif temperature >= 32:
        score += 20

    if humidity >= 80 and temperature >= 35:
        score += 20

    elif humidity >= 60 and temperature >= 35:
        score += 10

    return clamp(score)


# ============================================================


def calculate_wind_risk(weather):

    wind = safe_float(
        weather.get("wind_speed")
    )

    shear = safe_float(
        weather.get("wind_shear")
    )

    score = 0

    if wind >= 60:
        score += 85

    elif wind >= 50:
        score += 70

    elif wind >= 40:
        score += 55

    elif wind >= 30:
        score += 40

    elif wind >= 20:
        score += 25

    elif wind >= 10:
        score += 10

    if shear >= 30:
        score += 15

    elif shear >= 20:
        score += 10

    return clamp(score)


# ============================================================


def calculate_humidity_risk(weather):

    humidity = safe_float(
        weather.get("humidity")
    )

    if humidity >= 98:
        return 90

    if humidity >= 95:
        return 75

    if humidity >= 90:
        return 60

    if humidity >= 80:
        return 40

    if humidity >= 70:
        return 20

    return 5


# ============================================================
# MASTER RISK ENGINE
# ============================================================


def calculate_risk(weather):

    thunderstorm = calculate_thunderstorm_risk(
        weather
    )

    cloudburst = calculate_cloudburst_risk(
        weather
    )

    flash_flood = calculate_flash_flood_risk(
        weather
    )

    heavy_rain = calculate_heavy_rain_risk(
        weather
    )

    heat = calculate_heat_risk(
        weather
    )

    wind = calculate_wind_risk(
        weather
    )

    humidity_risk = calculate_humidity_risk(
        weather
    )

    # Main disaster risk

    overall = max(
        thunderstorm,
        cloudburst,
        flash_flood,
        heavy_rain,
        heat,
        wind
    )

    # Additional atmospheric influence

    cape = safe_float(
        weather.get("cape")
    )

    if cape >= 2000:

        overall += 5

    elif cape >= 1000:

        overall += 2

    overall = clamp(
        overall
    )

    level = risk_level(
        overall
    )

    # Determine dominant hazard

    hazards = {

        "Thunderstorm": thunderstorm,

        "Cloudburst": cloudburst,

        "Flash Flood": flash_flood,

        "Heavy Rain": heavy_rain,

        "Heat": heat,

        "Strong Wind": wind
    }

    dominant_hazard = max(
        hazards,
        key=hazards.get
    )

    # Alert severity

    if overall >= 85:

        alert_severity = "CRITICAL"

    elif overall >= 70:

        alert_severity = "SEVERE"

    elif overall >= 50:

        alert_severity = "WARNING"

    elif overall >= 30:

        alert_severity = "WATCH"

    else:

        alert_severity = "NORMAL"

    # Confidence estimate

    available_inputs = 0

    total_inputs = 15

    for key in [

        "temperature",
        "humidity",
        "pressure",
        "wind_u",
        "wind_v",
        "rainfall",
        "iwv",
        "cape",
        "cin",
        "ctt",
        "ctt_drop_rate",
        "wind_convergence",
        "wind_shear",
        "elevation",
        "slope"

    ]:

        if key in weather:

            available_inputs += 1

    confidence = (
        available_inputs /
        total_inputs
    ) * 100

    confidence = clamp(
        confidence
    )

    # Warning message

    if overall >= 85:

        message = (
            "Critical atmospheric risk detected. "
            "Immediate monitoring and emergency preparedness recommended."
        )

    elif overall >= 70:

        message = (
            "Severe weather risk detected. "
            "Local authorities and communities should remain alert."
        )

    elif overall >= 50:

        message = (
            "High weather-related risk detected. "
            "Enhanced monitoring is recommended."
        )

    elif overall >= 30:

        message = (
            "Moderate risk detected. "
            "Continue monitoring changing weather conditions."
        )

    elif overall >= 15:

        message = (
            "Low risk detected. "
            "Normal monitoring is sufficient."
        )

    else:

        message = (
            "Very low immediate hazard risk detected."
        )

    # Safety recommendation

    if dominant_hazard == "Thunderstorm":

        recommendation = (
            "Avoid exposed areas, tall isolated objects and open fields "
            "during thunderstorm activity."
        )

    elif dominant_hazard == "Cloudburst":

        recommendation = (
            "Avoid low-lying areas and monitor intense rainfall alerts."
        )

    elif dominant_hazard == "Flash Flood":

        recommendation = (
            "Avoid flooded roads, drainage channels and low-lying areas."
        )

    elif dominant_hazard == "Heavy Rain":

        recommendation = (
            "Monitor rainfall intensity and avoid unnecessary travel."
        )

    elif dominant_hazard == "Heat":

        recommendation = (
            "Maintain hydration and avoid prolonged exposure to extreme heat."
        )

    elif dominant_hazard == "Strong Wind":

        recommendation = (
            "Stay away from unstable structures, trees and exposed objects."
        )

    else:

        recommendation = (
            "Continue normal weather monitoring."
        )

    return {

        "thunderstorm_probability":
            round(thunderstorm, 2),

        "cloudburst_probability":
            round(cloudburst, 2),

        "flash_flood_probability":
            round(flash_flood, 2),

        "heavy_rain_probability":
            round(heavy_rain, 2),

        "heat_risk":
            round(heat, 2),

        "wind_risk":
            round(wind, 2),

        "humidity_risk":
            round(humidity_risk, 2),

        "overall_probability":
            round(overall, 2),

        "risk_level":
            level,

        "risk_class":
            risk_class(overall),

        "dominant_hazard":
            dominant_hazard,

        "alert_severity":
            alert_severity,

        "confidence":
            round(confidence, 2),

        "warning_message":
            message,

        "recommendation":
            recommendation,

        "hazards": hazards
    }


# ============================================================
# HOME
# ============================================================


@app.get("/")
def home():

    return {

        "project":
            PROJECT_NAME,

        "title":
            PROJECT_TITLE,

        "version":
            VERSION,

        "status":
            "online",

        "message":
            "Hyper-Local Early Warning System",

        "docs":
            "/docs",

        "health":
            "/health",

        "timestamp":
            datetime.now().isoformat()
    }


# ============================================================
# HEALTH
# ============================================================


@app.get("/health")
def health():

    weather_module = (
        get_weather is not None
    )

    forecast_module = (
        get_forecast is not None
    )

    return {

        "status":
            "healthy",

        "project":
            PROJECT_NAME,

        "version":
            VERSION,

        "weather_module":
            weather_module,

        "forecast_module":
            forecast_module,

        "time":
            datetime.now().isoformat()
    }


# ============================================================
# SYSTEM STATUS
# ============================================================


@app.get("/api/status")
def system_status():

    return {

        "project":
            PROJECT_NAME,

        "system":
            PROJECT_TITLE,

        "version":
            VERSION,

        "backend":
            "ONLINE",

        "weather_service":
            "AVAILABLE"
            if get_weather
            else "UNAVAILABLE",

        "forecast_service":
            "AVAILABLE"
            if get_forecast
            else "UNAVAILABLE",

        "api":
            "READY",

        "started_at":
            STARTED_AT,

        "current_time":
            datetime.now().isoformat()
    }


# ============================================================
# TEST
# ============================================================


@app.get("/api/test")
def test():

    return {

        "success":
            True,

        "project":
            PROJECT_NAME,

        "message":
            "SIH26077 backend is working",

        "timestamp":
            datetime.now().isoformat()
    }


# ============================================================
# LOCATION VALIDATION
# ============================================================


@app.post("/api/location/validate")
def validate_location(
    location: LocationInput
):

    return {

        "valid":
            True,

        "latitude":
            location.latitude,

        "longitude":
            location.longitude,

        "message":
            "Coordinates are valid."
    }


# ============================================================
# MANUAL PREDICTION
# ============================================================


@app.post("/api/predict")
def predict(
    weather: WeatherInput
):

    weather_data = weather.model_dump()

    prediction = calculate_risk(
        weather_data
    )

    return {

        "project":
            PROJECT_NAME,

        "weather":
            weather_data,

        "prediction":
            prediction,

        "timestamp":
            datetime.now().isoformat()
    }


# ============================================================
# LOCATION PREDICTION
# ============================================================


@app.post("/api/location-predict")
def location_predict(
    location: LocationInput
):

    latitude = location.latitude

    longitude = location.longitude

    if get_weather is None:

        raise HTTPException(
            status_code=503,
            detail="Weather service unavailable."
        )

    try:

        weather = get_weather(
            latitude,
            longitude
        )

        if not isinstance(
            weather,
            dict
        ):

            weather = {}

        prediction = calculate_risk(
            weather
        )

        return {

            "project":
                PROJECT_NAME,

            "location": {

                "latitude":
                    latitude,

                "longitude":
                    longitude
            },

            "real_weather":
                weather,

            "prediction":
                prediction,

            "timestamp":
                datetime.now().isoformat()
        }

    except Exception as error:

        print(
            "Location prediction error:"
        )

        traceback.print_exc()

        raise HTTPException(

            status_code=500,

            detail=str(error)
        )


# ============================================================
# FORECAST
# ============================================================


@app.get("/api/forecast")
def forecast(

    latitude: float = 23.55,

    longitude: float = 87.29

):

    if get_forecast is None:

        raise HTTPException(
            status_code=503,
            detail="Forecast service unavailable."
        )

    if not (
        -90 <= latitude <= 90
        and
        -180 <= longitude <= 180
    ):

        raise HTTPException(
            status_code=400,
            detail="Invalid coordinates."
        )

    try:

        raw_forecast = get_forecast(
            latitude,
            longitude
        )

        if not raw_forecast:

            return {

                "project":
                    PROJECT_NAME,

                "forecast_hours":
                    0,

                "data":
                    []
            }

        forecast_data = []

        for item in raw_forecast:

            if not isinstance(
                item,
                dict
            ):

                continue

            prediction = calculate_risk(
                item
            )

            forecast_data.append({

                "time":
                    item.get(
                        "time",
                        ""
                    ),

                "temperature":
                    round(
                        safe_float(
                            item.get(
                                "temperature"
                            )
                        ),
                        1
                    ),

                "humidity":
                    round(
                        safe_float(
                            item.get(
                                "humidity"
                            )
                        ),
                        1
                    ),

                "rainfall":
                    round(
                        safe_float(
                            item.get(
                                "rainfall"
                            )
                        ),
                        2
                    ),

                "wind_speed":
                    round(
                        safe_float(
                            item.get(
                                "wind_speed"
                            )
                        ),
                        1
                    ),

                "pressure":
                    round(
                        safe_float(
                            item.get(
                                "pressure"
                            )
                        ),
                        1
                    ),

                "thunderstorm_probability":
                    prediction[
                        "thunderstorm_probability"
                    ],

                "cloudburst_probability":
                    prediction[
                        "cloudburst_probability"
                    ],

                "flash_flood_probability":
                    prediction[
                        "flash_flood_probability"
                    ],

                "heavy_rain_probability":
                    prediction[
                        "heavy_rain_probability"
                    ],

                "heat_risk":
                    prediction[
                        "heat_risk"
                    ],

                "wind_risk":
                    prediction[
                        "wind_risk"
                    ],

                "overall_probability":
                    prediction[
                        "overall_probability"
                    ],

                "risk_level":
                    prediction[
                        "risk_level"
                    ],

                "dominant_hazard":
                    prediction[
                        "dominant_hazard"
                    ],

                "alert_severity":
                    prediction[
                        "alert_severity"
                    ]
            })

        # Maximum forecast risk

        max_risk = 0

        max_item = None

        for item in forecast_data:

            score = safe_float(
                item.get(
                    "overall_probability"
                )
            )

            if score > max_risk:

                max_risk = score

                max_item = item

        return {

            "project":
                PROJECT_NAME,

            "latitude":
                latitude,

            "longitude":
                longitude,

            "forecast_hours":
                len(forecast_data),

            "timezone":
                "local",

            "maximum_risk":
                round(
                    max_risk,
                    2
                ),

            "maximum_risk_level":
                risk_level(
                    max_risk
                ),

            "maximum_risk_time":
                (
                    max_item.get(
                        "time"
                    )
                    if max_item
                    else None
                ),

            "updated_at":
                datetime.now().isoformat(),

            "data":
                forecast_data
        }

    except Exception as error:

        print(
            "Forecast error:"
        )

        traceback.print_exc()

        raise HTTPException(

            status_code=500,

            detail=str(error)
        )


# ============================================================
# FORECAST STATISTICS
# ============================================================


@app.get("/api/forecast/statistics")
def forecast_statistics(

    latitude: float = 23.55,

    longitude: float = 87.29

):

    result = forecast(
        latitude,
        longitude
    )

    data = result.get(
        "data",
        []
    )

    if not data:

        return {

            "project":
                PROJECT_NAME,

            "count":
                0,

            "statistics":
                {}
        }

    temperatures = [
        safe_float(
            x.get(
                "temperature"
            )
        )
        for x in data
    ]

    rainfall = [
        safe_float(
            x.get(
                "rainfall"
            )
        )
        for x in data
    ]

    risks = [
        safe_float(
            x.get(
                "overall_probability"
            )
        )
        for x in data
    ]

    return {

        "project":
            PROJECT_NAME,

        "count":
            len(data),

        "temperature": {

            "minimum":
                round(
                    min(temperatures),
                    1
                ),

            "maximum":
                round(
                    max(temperatures),
                    1
                ),

            "average":
                round(
                    sum(temperatures)
                    / len(temperatures),
                    1
                )
        },

        "rainfall": {

            "minimum":
                round(
                    min(rainfall),
                    2
                ),

            "maximum":
                round(
                    max(rainfall),
                    2
                ),

            "total":
                round(
                    sum(rainfall),
                    2
                )
        },

        "risk": {

            "minimum":
                round(
                    min(risks),
                    2
                ),

            "maximum":
                round(
                    max(risks),
                    2
                ),

            "average":
                round(
                    sum(risks)
                    / len(risks),
                    2
                )
        }
    }


# ============================================================
# ALERTS
# ============================================================


@app.get("/api/alerts")
def alerts(

    latitude: float = 23.55,

    longitude: float = 87.29

):

    result = forecast(
        latitude,
        longitude
    )

    data = result.get(
        "data",
        []
    )

    alerts_data = []

    for item in data:

        probability = safe_float(
            item.get(
                "overall_probability"
            )
        )

        if probability >= 50:

            alerts_data.append({

                "time":
                    item.get(
                        "time"
                    ),

                "risk":
                    probability,

                "level":
                    item.get(
                        "risk_level"
                    ),

                "severity":
                    item.get(
                        "alert_severity"
                    ),

                "hazard":
                    item.get(
                        "dominant_hazard"
                    ),

                "message":
                    (
                        f"{item.get('dominant_hazard')} "
                        f"risk is {round(probability)}%."
                    )
            })

    return {

        "project":
            PROJECT_NAME,

        "alert_count":
            len(alerts_data),

        "alerts":
            alerts_data,

        "timestamp":
            datetime.now().isoformat()
    }


# ============================================================
# DASHBOARD SUMMARY
# ============================================================


@app.post("/api/dashboard")
def dashboard(
    location: LocationInput
):

    if get_weather is None:

        raise HTTPException(
            status_code=503,
            detail="Weather service unavailable."
        )

    try:

        weather = get_weather(
            location.latitude,
            location.longitude
        )

        if not isinstance(
            weather,
            dict
        ):

            weather = {}

        prediction = calculate_risk(
            weather
        )

        return {

            "project":
                PROJECT_NAME,

            "dashboard": {

                "status":
                    "LIVE",

                "location": {

                    "latitude":
                        location.latitude,

                    "longitude":
                        location.longitude
                },

                "weather":
                    weather,

                "risk":
                    prediction,

                "last_updated":
                    datetime.now().isoformat()
            }
        }

    except Exception as error:

        traceback.print_exc()

        raise HTTPException(

            status_code=500,

            detail=str(error)
        )


# ============================================================
# RISK GRID
# ============================================================


@app.get("/api/risk-grid")
def risk_grid():

    locations = [

        (
            23.6739,
            87.1483
        ),

        (
            23.5200,
            87.3100
        ),

        (
            23.5500,
            87.2900
        ),

        (
            23.2500,
            87.8500
        ),

        (
            22.5700,
            88.3600
        ),

        (
            23.2400,
            87.8700
        ),

        (
            23.0700,
            87.3200
        ),

        (
            22.7200,
            88.4800
        ),

        (
            23.6000,
            87.1000
        ),

        (
            23.4500,
            87.3200
        )
    ]

    data = []

    if get_weather is None:

        return {

            "project":
                PROJECT_NAME,

            "cells":
                0,

            "data":
                [],

            "error":
                "Weather service unavailable."
        }

    for latitude, longitude in locations:

        try:

            weather = get_weather(
                latitude,
                longitude
            )

            if not isinstance(
                weather,
                dict
            ):

                weather = {}

            prediction = calculate_risk(
                weather
            )

            data.append({

                "latitude":
                    latitude,

                "longitude":
                    longitude,

                "temperature":
                    safe_float(
                        weather.get(
                            "temperature"
                        )
                    ),

                "humidity":
                    safe_float(
                        weather.get(
                            "humidity"
                        )
                    ),

                "rainfall":
                    safe_float(
                        weather.get(
                            "rainfall"
                        )
                    ),

                "wind_speed":
                    safe_float(
                        weather.get(
                            "wind_speed"
                        )
                    ),

                "overall_probability":
                    prediction[
                        "overall_probability"
                    ],

                "risk_level":
                    prediction[
                        "risk_level"
                    ],

                "risk_class":
                    prediction[
                        "risk_class"
                    ],

                "dominant_hazard":
                    prediction[
                        "dominant_hazard"
                    ],

                "alert_severity":
                    prediction[
                        "alert_severity"
                    ]
            })

        except Exception as error:

            print(
                "Grid error:",
                error
            )

    return {

        "project":
            PROJECT_NAME,

        "cells":
            len(data),

        "timestamp":
            datetime.now().isoformat(),

        "data":
            data
    }


# ============================================================
# RISK SUMMARY
# ============================================================


@app.get("/api/risk-summary")
def risk_summary():

    result = risk_grid()

    data = result.get(
        "data",
        []
    )

    if not data:

        return {

            "project":
                PROJECT_NAME,

            "total_locations":
                0,

            "summary":
                {}
        }

    levels = {

        "VERY LOW": 0,

        "LOW": 0,

        "MODERATE": 0,

        "HIGH": 0,

        "VERY HIGH": 0,

        "EXTREME": 0
    }

    highest = None

    highest_score = -1

    for item in data:

        level = item.get(
            "risk_level",
            "VERY LOW"
        )

        if level in levels:

            levels[level] += 1

        score = safe_float(
            item.get(
                "overall_probability"
            )
        )

        if score > highest_score:

            highest_score = score

            highest = item

    return {

        "project":
            PROJECT_NAME,

        "total_locations":
            len(data),

        "risk_distribution":
            levels,

        "highest_risk_location":
            highest,

        "timestamp":
            datetime.now().isoformat()
    }


# ============================================================
# SYSTEM FEATURES
# ============================================================


@app.get("/api/features")
def features():

    return {

        "project":
            PROJECT_NAME,

        "feature_count":
            50,

        "features": [

            "Real-time weather monitoring",

            "24-hour weather forecast",

            "Hyper-local location analysis",

            "Thunderstorm risk",

            "Cloudburst risk",

            "Flash-flood risk",

            "Heavy-rain risk",

            "Heat risk",

            "Strong-wind risk",

            "Humidity risk",

            "Overall risk scoring",

            "Risk-level classification",

            "Dominant hazard detection",

            "Alert severity",

            "Early-warning messages",

            "Safety recommendations",

            "Risk confidence",

            "Regional risk grid",

            "Forecast statistics",

            "Maximum-risk detection",

            "Latitude validation",

            "Longitude validation",

            "CAPE analysis",

            "CIN analysis",

            "IWV analysis",

            "CTT support",

            "CTT drop-rate support",

            "Wind convergence",

            "Wind shear",

            "Elevation analysis",

            "Slope analysis",

            "Dashboard summary",

            "API health monitoring",

            "Backend status",

            "Weather-service status",

            "Forecast-service status",

            "CORS support",

            "Automatic timestamps",

            "Structured JSON responses",

            "REST API architecture",

            "Swagger documentation",

            "ReDoc documentation",

            "Error handling",

            "Modular risk engine",

            "Regional monitoring",

            "Alert API",

            "Risk summary API",

            "Forecast statistics API",

            "Future ML integration",

            "Dashboard-ready backend"
        ]
    }


# ============================================================
# PROJECT INFO
# ============================================================


@app.get("/api/project")
def project_info():

    return {

        "project":
            PROJECT_NAME,

        "title":
            PROJECT_TITLE,

        "version":
            VERSION,

        "purpose":
            (
                "Hyper-local multi-hazard "
                "early warning and risk monitoring."
            ),

        "architecture": {

            "frontend":
                "HTML/CSS/JavaScript",

            "backend":
                "FastAPI",

            "server":
                "Uvicorn",

            "future_ml":
                "Ready",

            "future_gis":
                "Ready",

            "future_database":
                "Ready"
        },

        "timestamp":
            datetime.now().isoformat()
    }


# ============================================================
# ERROR HANDLER
# ============================================================


@app.get("/api/debug")
def debug():

    return {

        "project":
            PROJECT_NAME,

        "python_backend":
            True,

        "weather_module_loaded":
            get_weather is not None,

        "forecast_module_loaded":
            get_forecast is not None,

        "timestamp":
            datetime.now().isoformat()
    }


# ============================================================
# RUN DIRECTLY
# ============================================================

if __name__ == "__main__":

    import uvicorn

    uvicorn.run(

        "backend.main:app",

        host="127.0.0.1",

        port=8000,

        reload=True
    )

