const API_URL = "http://127.0.0.1:8001";


async function getPrediction() {

    const latitude =
        parseFloat(
            document.getElementById("latitude").value
        );

    const longitude =
        parseFloat(
            document.getElementById("longitude").value
        );


    if (
        Number.isNaN(latitude) ||
        Number.isNaN(longitude)
    ) {

        alert("Please enter valid coordinates.");

        return;
    }


    try {

        const response = await fetch(
            `${API_URL}/api/location-predict`,
            {

                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    latitude: latitude,
                    longitude: longitude
                })

            }
        );


        if (!response.ok) {

            throw new Error(
                `Server error: ${response.status}`
            );
        }


        const data =
            await response.json();


        updateDashboard(data);

    }

    catch (error) {

        console.error(error);

        alert(
            "Backend connection failed. Make sure FastAPI is running on port 8001."
        );
    }
}


function updateDashboard(data) {

    const weather =
        data.real_weather || {};

    const prediction =
        data.prediction || {};


    document.getElementById("temperature").textContent =
        Number(weather.temperature || 0).toFixed(1);


    document.getElementById("humidity").textContent =
        Number(weather.humidity || 0).toFixed(1);


    document.getElementById("rainfall").textContent =
        Number(weather.rainfall || 0).toFixed(2);


    document.getElementById("wind").textContent =
        Number(weather.wind_speed || 0).toFixed(1);


    document.getElementById("pressure").textContent =
        Number(weather.pressure || 0).toFixed(1);


    document.getElementById("overallRisk").textContent =
        Number(
            prediction.overall_probability || 0
        ).toFixed(0);


    document.getElementById("riskLevel").textContent =
        prediction.risk_level ||
        "UNKNOWN";


    document.getElementById("dominantHazard").textContent =
        prediction.dominant_hazard ||
        "Unknown";


    document.getElementById("warningMessage").textContent =
        prediction.warning_message ||
        "No warning available.";


    document.getElementById("recommendation").textContent =
        prediction.recommendation ||
        "No recommendation available.";


    document.getElementById("thunderstorm").textContent =
        `${prediction.thunderstorm_probability || 0}%`;


    document.getElementById("cloudburst").textContent =
        `${prediction.cloudburst_probability || 0}%`;


    document.getElementById("flood").textContent =
        `${prediction.flash_flood_probability || 0}%`;


    document.getElementById("heavyRain").textContent =
        `${prediction.heavy_rain_probability || 0}%`;


    document.getElementById("heat").textContent =
        `${prediction.heat_risk || 0}%`;


    document.getElementById("windRisk").textContent =
        `${prediction.wind_risk || 0}%`;


    document.getElementById("hazardInfo").textContent =
        prediction.dominant_hazard ||
        "Unknown";


    document.getElementById("alertSeverity").textContent =
        prediction.alert_severity ||
        "NORMAL";


    document.getElementById("confidence").textContent =
        `${prediction.confidence || 0}%`;
}